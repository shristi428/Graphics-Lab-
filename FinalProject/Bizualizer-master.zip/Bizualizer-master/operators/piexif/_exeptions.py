class InvalidImageDataError(ValueError):
    pass